import "./Text.css"
export function Text({txt}){

    return (<> 
    <p>{txt}</p>
    </>
    );
}

export default Text;