import './Boton.css';

function Boton({ sendText }) {
  return <button type="submit" class="allMayus myBtn">{ sendText }</button>;
}

export default Boton;